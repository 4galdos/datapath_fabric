# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "a5642336-bd63-407f-a021-46aa4ce01974",
# META       "default_lakehouse_name": "LKH_PROYECTO_DATAPATH_AGC",
# META       "default_lakehouse_workspace_id": "f397882e-0f39-4c30-9877-bb64c3f38997",
# META       "known_lakehouses": [
# META         {
# META           "id": "a5642336-bd63-407f-a021-46aa4ce01974"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# En este notebook aprenderemos a:
# Leer los datos con PySpark
# Realizar transformaciones
# Guardar los dataframes como tablas Delta
# Crear un modelo estrella para análisis

#Configuración inicial y verificación del entorno
# Este comando verifica que estamos en el entorno correcto de Fabric

import pyspark.sql.functions as F
from pyspark.sql.types import *
from notebookutils import mssparkutils
import pandas as pd

# Verificar versión de Spark
print(f"Versión de Spark: {spark.version}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Crear estructura de carpetas en el lakehouse
# Este comando crea las carpetas necesarias en el lakehouse para almacenar nuestros archivos

try:
    # Crear carpetas para datos brutos y procesados
    mssparkutils.fs.mkdirs("Files/raw")
    mssparkutils.fs.mkdirs("Files/silver")
    mssparkutils.fs.mkdirs("Files/gold")
    mssparkutils.fs.mkdirs("Files/processed")
    print("✅ Estructura de carpetas creada correctamente")
except Exception as e:
    print(f"Error al crear carpetas: {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Definición de esquemas para mejor control de los datos
# Definimos los esquemas de nuestros dataframes para asegurar tipos de datos correctos

# Esquema para Broker
schema_broker = StructType([
    StructField("BrokerID", IntegerType(), False),
    StructField("BrokerName", StringType(), True),
    StructField("Region", StringType(), True),
    StructField("Email", StringType(), True)
])

# Esquema para Compaign
schema_campaign = StructType([
    StructField("CampaignID", IntegerType(), False),
    StructField("Channel", StringType(), True),
    StructField("CampaignName", StringType(), True),
    StructField("StartDate", DateType(), True),
    StructField("EndDate", DateType(), True),
    StructField("BudgetUSD", DoubleType(), True)
])

# Esquema para Client
schema_client = StructType([
    StructField("ClientID", IntegerType(), False),
    StructField("FirstName", StringType(), True),
    StructField("LastName", StringType(), True),
    StructField("Email", StringType(), True),
    StructField("Region", StringType(), True)
])

# Esquema para Lead
schema_lead = StructType([
    StructField("LeadID", IntegerType(), False),
    StructField("ClientID", IntegerType(), False),
    StructField("PropertyID", IntegerType(), False),
    StructField("CampaignID", IntegerType(), False),
    StructField("LeadDate", DateType(), True),
    StructField("LeadSource", StringType(), True)
])

# Esquema para Project
schema_project = StructType([
    StructField("ProjectID", IntegerType(), False),
    StructField("ProjectName", StringType(), True),
    StructField("City", StringType(), True),
    StructField("Region", StringType(), True),
    StructField("LaunchYear", IntegerType(), True),
    StructField("Status", StringType(), True)
])


# Esquema para Property
schema_property = StructType([
    StructField("PropertyID", IntegerType(), False),
    StructField("ProjectID", IntegerType(), False),
    StructField("PropertyType", StringType(), True),
    StructField("Size_m2", IntegerType(), True),
    StructField("Bedrooms", IntegerType(), True),
    StructField("Bathrooms", IntegerType(), True),
    StructField("ListPriceUSD", DoubleType(), True),
    StructField("AvailabilityStatus", StringType(), True)
])


# Esquema para sales
schema_sales = StructType([
    StructField("SaleID", IntegerType(), False),
    StructField("PropertyID", IntegerType(), False),
    StructField("ClientID", IntegerType(), False),
    StructField("BrokerID", IntegerType(), False),
    StructField("SaleDate", DateType(), False),
    StructField("SalePriceUSD", DoubleType(), True)
])

print("✅ Esquemas definidos correctamente")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Leer los archivos CSV con los esquemas definidos
# Este comando lee los archivos CSV utilizando los esquemas definidos anteriormente

try:
    # Leer archivo de broker
    df_broker = spark.read.format("csv") \
        .option("header", "true") \
        .schema(schema_broker) \
        .load("Files/raw/brokers.csv")
    
    # Leer archivo de campaign
    df_campaign = spark.read.format("csv") \
        .option("header", "true") \
        .schema(schema_campaign) \
        .load("Files/raw/campaigns.csv")
    
    # Leer archivo de client
    df_client = spark.read.format("csv") \
        .option("header", "true") \
        .schema(schema_client) \
        .load("Files/raw/clients.csv")
    
    # Leer archivo de lead
    df_lead = spark.read.format("csv") \
        .option("header", "true") \
        .schema(schema_lead) \
        .load("Files/raw/leads.csv")

    # Leer archivo de projects
    df_project = spark.read.format("csv") \
        .option("header", "true") \
        .schema(schema_project) \
        .load("Files/raw/projects.csv")

    # Leer archivo de property
    df_property = spark.read.format("csv") \
        .option("header", "true") \
        .schema(schema_property) \
        .load("Files/raw/properties.csv")

    # Leer archivo de sales
    df_sales = spark.read.format("csv") \
        .option("header", "true") \
        .schema(schema_sales) \
        .load("Files/raw/sales.csv")
    
    print("✅ Archivos CSV leídos correctamente")
except Exception as e:
    print(f"Error al leer archivos: {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Exploración de los datos
# Mostramos una vista previa de los datos cargados

print("Vista previa de los datos de df_broker:")
display(df_broker.limit(5))

print("Vista previa de los datos de df_campaign:")
display(df_campaign.limit(5))

print("Vista previa de los datos de df_client:")
display(df_client.limit(5))

print("Vista previa de los datos de df_lead:")
display(df_lead.limit(5))

print("Vista previa de los datos de df_project:")
display(df_project.limit(5))

print("Vista previa de los datos de df_property:")
display(df_property.limit(5))

print("Vista previa de los datos de df_sales:")
display(df_sales.limit(5))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Información sobre los dataframes
# Mostramos el esquema y contamos los registros en cada tabla

print("Información del dataframe de df_broker:")
print(f"Número de registros: {df_broker.count()}")
df_broker.printSchema()

print("\nInformación del dataframe de df_campaign:")
print(f"Número de registros: {df_campaign.count()}")
df_campaign.printSchema()

print("\nInformación del dataframe de df_client:")
print(f"Número de registros: {df_client.count()}")
df_client.printSchema()

print("\nInformación del dataframe de df_lead:")
print(f"Número de registros: {df_lead.count()}")
df_lead.printSchema()

print("\nInformación del dataframe de df_project:")
print(f"Número de registros: {df_project.count()}")
df_project.printSchema()

print("\nInformación del dataframe de df_property:")
print(f"Número de registros: {df_property.count()}")
df_property.printSchema()

print("\nInformación del dataframe de df_sales:")
print(f"Número de registros: {df_sales.count()}")
df_sales.printSchema()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Guardar los dataframes como tablas Delta
# Guardamos los dataframes procesados como tablas Delta en el lakehouse

try:
    # Guardar df_broker
    df_broker.write.format("delta").mode("overwrite").save("Files/gold/broker_delta")
    
    # Guardar df_campaign
    df_campaign.write.format("delta").mode("overwrite").save("Files/gold/campaign_delta")
    
    # Guardar df_client
    df_client.write.format("delta").mode("overwrite").save("Files/gold/client_delta")
    
    # Guardar df_lead
    df_lead.write.format("delta").mode("overwrite").save("Files/gold/lead_delta")
    
    # Guardar df_project
    df_project.write.format("delta").mode("overwrite").save("Files/gold/project_delta")

    # Guardar df_property
    df_property.write.format("delta").mode("overwrite").save("Files/gold/property_delta")

    # Guardar df_property
    df_sales.write.format("delta").mode("overwrite").save("Files/gold/sales_delta")

    
    print("✅ Dataframes guardados como archivos Delta correctamente")
except Exception as e:
    print(f"Error al guardar archivos Delta: {str(e)}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Registrar tablas como vistas temporales en la sesión actual

try:
    # Registrar tablas como vistas temporales
    df_property.createOrReplaceTempView("dim_property")
    df_broker.createOrReplaceTempView("dim_broker")
    df_campaign.createOrReplaceTempView("dim_campaign")
    df_project.createOrReplaceTempView("dim_project")
    df_client.createOrReplaceTempView("dim_client")

    df_lead.createOrReplaceTempView("fact_lead")
    df_sales.createOrReplaceTempView("fact_sales")
    
    # Verificar que se han creado correctamente
    tables = spark.sql("SHOW TABLES").collect()
    print("Tablas disponibles en la sesión:")
    for table in tables:
        print(f" - {table.tableName}")
    
    print("✅ Vistas temporales creadas correctamente para la sesión actual")
    
    # Alternativa: Guardar como tablas directamente en el Lakehouse 
    # Esto registra las tablas en el catálogo del Lakehouse actual
    print("\nRegistrando tablas en el catálogo del Lakehouse...")
    
    # Registrar los dataframes como tablas en el Lakehouse actual parte Tables
    df_property.write.format("delta").mode("overwrite").saveAsTable("dim_property")
    df_broker.write.format("delta").mode("overwrite").saveAsTable("dim_broker")
    df_campaign.write.format("delta").mode("overwrite").saveAsTable("dim_campaign")
    df_project.write.format("delta").mode("overwrite").saveAsTable("dim_project")
    df_client.write.format("delta").mode("overwrite").saveAsTable("dim_client")

    df_lead.write.format("delta").mode("overwrite").saveAsTable("fact_lead")
    df_sales.write.format("delta").mode("overwrite").saveAsTable("fact_sales")
    
    print("✅ Tablas creadas correctamente en el catálogo del Lakehouse")
except Exception as e:
    print(f"Error al crear tablas: {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Consultar el modelo estrella completo
# Realizamos una consulta SQL que une todas las tablas del modelo estrella

query = """
SELECT 
    v.id_venta,
    t.fecha,
    t.tipo_dia,
    c.nombre_completo AS cliente,
    c.ciudad AS ciudad_cliente,
    p.nombre AS producto,
    p.categoria,
    p.subcategoria,
    ti.nombre AS tienda,
    ti.ciudad AS ciudad_tienda,
    v.cantidad,
    v.precio_unitario,
    v.descuento,
    v.total,
    v.porcentaje_descuento
FROM 
    fact_ventas v
JOIN 
    dim_tiempo t ON v.id_fecha = t.id_fecha
JOIN 
    dim_clientes c ON v.id_cliente = c.id_cliente
JOIN 
    dim_productos p ON v.id_producto = p.id_producto
JOIN 
    dim_tiendas ti ON v.id_tienda = ti.id_tienda
ORDER BY 
    v.id_venta
"""

try:
    # Ejecutar la consulta
    resultado = spark.sql(query)
    
    # Mostrar los resultados
    print("Consulta del modelo estrella completo:")
    display(resultado)
    
    print("✅ Consulta ejecutada correctamente")
except Exception as e:
    print(f"Error al ejecutar la consulta: {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

# Análisis básico de ventas
# Realizamos un análisis básico de las ventas por categoría de producto

query_analisis = """
SELECT 
    p.categoria,
    COUNT(*) AS num_ventas,
    SUM(v.total) AS ventas_totales,
    AVG(v.total) AS venta_promedio,
    SUM(v.descuento) AS descuentos_totales
FROM 
    fact_ventas v
JOIN 
    dim_productos p ON v.id_producto = p.id_producto
GROUP BY 
    p.categoria
ORDER BY 
    ventas_totales DESC
"""

try:
    # Ejecutar la consulta de análisis
    resultado_analisis = spark.sql(query_analisis)
    
    # Mostrar los resultados
    print("Análisis de ventas por categoría:")
    display(resultado_analisis)
    
    # Convertir a pandas para visualización
    df_analisis_pd = resultado_analisis.toPandas()
    
    # Visualizar con matplotlib (si está disponible)
    try:
        import matplotlib.pyplot as plt
        
        plt.figure(figsize=(10, 6))
        plt.bar(df_analisis_pd['categoria'], df_analisis_pd['ventas_totales'])
        plt.title('Ventas totales por categoría')
        plt.xlabel('Categoría')
        plt.ylabel('Ventas totales (€)')
        plt.xticks(rotation=45)
        plt.tight_layout()
        display(plt.gcf())
    except ImportError:
        print("Matplotlib no está disponible para visualización. Mostrando datos en formato tabular.")
        
    print("✅ Análisis completado correctamente")
except Exception as e:
    print(f"Error al ejecutar análisis: {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Guardar el resultado del análisis
# Guardamos el resultado del análisis como archivo CSV

try:
    # Convertir a pandas para guardarlo como CSV
    df_analisis_pd.to_csv("/tmp/analisis_ventas_categoria.csv", index=False)
    
    # Subir al lakehouse
    mssparkutils.fs.put("Files/processed/analisis_ventas_categoria.csv", 
                        "/tmp/analisis_ventas_categoria.csv", True)
    
    print("✅ Resultado del análisis guardado como CSV en 'Files/processed/analisis_ventas_categoria.csv'")
except Exception as e:
    print(f"Error al guardar resultado: {str(e)}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
